
Step 1: run unlock.bat as administrator priority to unlock BIOS and the system will restart.
Step 2: run 14T90P_GramLOGO.cmd for 14T90P or 16T90P_GramLOGO.cmd for 16T90P as administrator priority

